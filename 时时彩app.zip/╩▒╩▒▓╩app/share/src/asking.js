$(function(){


		 $.ajax({
             type: "post",
             url: "https://www.jindi163.com:8443/JDLot/lot/type/pagelist",
             data: {"table_name":"gsks","PageNum":"1","PageSize":num},
             async:true,
             contentType: "application/json",
             dataType: "json",
     success:function(){
            
             }
             error:function(){

             }
	})
})