$(function(){
function GetRequest() {
var url = location.search; //获取url中"?"符后的字串
var theRequest = new Object();
if (url.indexOf("?") != -1) {
var str = url.substr(1);
strs = str.split("&");
for(var i = 0; i < strs.length; i ++) {
theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
}
}
return theRequest;
}
var Request = new Object();
Request = GetRequest()
if(Request["uid"]!=undefined){
var uid = Request["uid"];
}
$.ajax({
             type: "post",
             url: "http://47.94.140.92:8080/JDLot/lottype/alllist",
             data: {"uid":uid,"PageSize":"100"},
             async:true,
             dataType: "json",
             success: function(data){
                   data=data.datas;
                   console.log(data)
                   $('#caizhongjiekou').empty();  
                   var html="";

                   $.each(data,function(i){
                      var good_name=data[i].lottery_name;
                      var good=good_name.substring(5);
                          good=good+"_trend.html";//链接
                        // console.log(good)
                      html+='<li><a href="'+good+'">'+data[i].lottery_full_name+'</a></li>'
                   })
                   $('#caizhongjiekou').append(html)
                 }

       })
})