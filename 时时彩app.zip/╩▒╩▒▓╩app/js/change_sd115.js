$(function(){
	   $("#inputs5").click(function(){
              $(".canvasdiv").show()
      })
      $("#inputs6").click(function(){
              $(".canvasdiv").hide()
      })
        var num=50;//num 显示数据长度
    $("#inputs1").click(function(){
      $(".canvasdiv canvas").remove();
      num=30;
      shows()
      $(".canvasdiv").append($("canvas"))
})
   $("#inputs2").click(function(){
     $(".canvasdiv canvas").remove();
     num=50;
    shows()
    $(".canvasdiv").append($("canvas"))
})
    $("#inputs3").click(function(){
       $(".canvasdiv canvas").remove();
       num=100;
       shows()
       $(".canvasdiv").append($("canvas"))
})
     $("#inputs4").click(function(){
       $(".canvasdiv canvas").remove();
       num=200;
       shows()
       $(".canvasdiv").append($("canvas"))
})
     $("#inputs9").click(function(){
       $("#totles").show();
       $("#totles1").show()
})
$("#inputs10").click(function(){
       $("#totles").hide();
       $("#totles1").hide();
})
                    shows()
   function shows(){//创建数据
         $.ajax({
             type: "post",
             url: "http://47.94.140.92:8080/JDLot/lot/type/pagelist",
             data: {"table_name":"sd115","PageNum":"1","PageSize":num},
             async:true,
             contentType: "application/json",
             dataType: "json",
             success: function(data){
                     data=data.datas;
                
                console.log(data)
                $('#great').empty();  
                 var html_great='<tr class="trss">'+
	            		'<th class="th_wt">期号</th>'+
                        '<th class="th_wt">和值</th>'+
	            		'<th>1</th>'+
	            		'<th>2</th>'+
	            		'<th>3</th>'+
	            		'<th>4</th>'+
	            		'<th>5</th>'+
	            		'<th>6</th>'+
                        '<th>7</th>'+
                        '<th>8</th>'+
                        '<th>9</th>'+
                        '<th>10</th>'+
                        '<th>11</th>'+
	            	'</tr>';
	            	var ids="";
                $.each(data,function(i){
                	var qihai=data[i].period;
                		qihai=qihai.substring(8);
                		var gewei=data[i].number.split(",").slice(0,3);
                        // console.log(gewei.length)
                		var aa=gewei.slice(0,1);
                		var aa1=gewei.slice(1,2);
                		var aa2=gewei.slice(2,3);
                        var sums=parseInt(Math.floor(aa))+parseInt(Math.floor(aa1))+parseInt(Math.floor(aa2));
                		var ss="",ss1="",ss2="";
                		var a="",b="",c="",d="",e="",f="",g="",h="",m="",n="",p="";

                        for (var k = 0; k < gewei.length; k++) {
                            if(gewei[k]==1){
                               a=1 
                            }
                       
                            if(gewei[k]==2){
                               b=2 
                            }
                            if(gewei[k]==3){
                               c=3 
                            }
                            if(gewei[k]==4){
                               d=4 
                            }
                            if(gewei[k]==5){
                               e=5 
                            }
                            if(gewei[k]==6){
                               f=6 
                            }
                            if(gewei[k]==7){
                               g=7 
                            }
                            if(gewei[k]==8){
                               h=8 
                            }
                            if(gewei[k]==9){
                               m=9
                            }
                            if(gewei[k]==10){
                               n=10
                            }
                            if(gewei[k]==11){
                               p=11
                            }
                        }

                	 html_great += '<tr>'+
                	 '<td style="color:#000;"><span>'+qihai+'</span></td>'+
                	 '<td><span style="color:#E65A59">'+sums+'</span></td>'+
                     '<td><span id="class_0'+i+'">'+a+'</span></td>'+
                	 '<td><span id="class_1'+i+'">'+b+'</span></td>'+
                	 '<td><span id="class_2'+i+'">'+c+'</span></td>'+
                	 '<td><span id="class_3'+i+'">'+d+'</span></td>'+
                	 '<td><span id="class_4'+i+'">'+e+'</span></td>'+
                	 '<td><span id="class_5'+i+'">'+f+'</span></td>'+
                     '<td><span id="class_6'+i+'">'+g+'</span></td>'+
                     '<td><span id="class_7'+i+'">'+h+'</span></td>'+
                     '<td><span id="class_8'+i+'">'+m+'</span></td>'+
                     '<td><span id="class_9'+i+'">'+n+'</span></td>'+
                     '<td><span id="class_10'+i+'">'+p+'</span></td>'+
                	 '</tr>';

 })
    $('#great').append(html_great);//将彩票彩种添加到$('#caizhongjiekou')上
    $("#totles").empty();
                     var shuju_zong='<li style="color: #579ee8;"><span class="times">出现次数</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span></li>'+
                     '<li style="color: #d88927;"><span class="times">平均遗漏</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span></li>'+
                     '<li style="color: #6e8d57;"><span class="times">最大遗漏</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span></li>'+
                     '<li style="color: #ea7de1;"><span class="times">最大连出</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10+10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span><span>'+parseInt(Math.random(1)*10)+'</span></li>';
                $("#totles").html(shuju_zong);

               	for (var i = 0; i < 12; i++) {  
               	 for (var j = 0; j <data.length; j++) {
                  
                  		ids+="class_"+i+j+",";
                	    }
                	 }
                	 ids = ids.substring(0, ids.length - 1);
                	 var list = ids.split(",");
                	   var dss=0;
                        var adds=0;
                for (var k = list.length-1; k >=0 ; k--) {//将匹配的ID放入arrList数组中
                var index=k;
                    if ($("#"+list[k]).text()!="") {
 
                        dss=0;adds+=1;
                        $("#"+list[k]).addClass("col");//给相应的span加上colors样式
                    } 
                    else{
                        dss++;adds=0;
                         // $(".class_"+[k]).show();
                           $("#"+list[k]).text(dss)
                        
                        
                    }
                }
     }

  })
}
})