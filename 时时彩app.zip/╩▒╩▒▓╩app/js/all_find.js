$(function(){

//获取uid
function GetRequest() {
      var url = location.search; //获取url中"?"符后的字串
      var theRequest = new Object();
      if (url.indexOf("?") != -1) {
      var str = url.substr(1);
      strs = str.split("&");
      for(var i = 0; i < strs.length; i ++) {
      theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
      }
      }
      return theRequest;
      }
      var Request = new Object();
      Request = GetRequest();
      if(Request["uid"]!=undefined){
      var uid = Request["uid"];
}
// console.log(uid)
      $.ajax({
           type:"post",
           
            // url:"http://47.94.140.92:8080/JDLot/lot/plan/jdlot/list", //总的url  child_name："A"    plan_id:"2_2_20_3_a_3"    plan_name:二期和值"
            // data: {"uid":uid,"PageSize":100,"lot_name":"ssc"}, 
            // url:"http://47.94.140.92:8080/JDLot/lot/plan/slist",//all 数据展示部分
            // data: {"uid":uid,"PageSize":100,"lottery_name":"cqssc","plan_id":"0_1_00_4_a_7"}, 

          url: "http://47.94.140.92:8080/JDLot/lottype/pagelist",//追号计划需要uid
          data: {"uid":uid,"PageSize":100}, 
           dataType: "json",
           contentType:"application/json",
            async:true,
           success: function(data){

//数组去重方法
Array.prototype.unique3 = function(){
     var res = [];
     var json = {};
     for(var i = 0; i < this.length; i++){
        if(!json[this[i]]){
           res.push(this[i]);
           json[this[i]] = 1;
        }
     }
  return res;
}
        var arr = [112,112,34,'你好',112,112,34,'你好','str','str1'];
        var arrss=arr.unique3();
        console.log(arrss);


                 data=data.datas;
                 console.log(data)
                 $('#caizhongjiekou').empty();

                 var html="";
                 var good_html=new Array();
                 var good="";
                 var fisrt="";
                 var mian_msg="";
                 $.each(data,function(i){
                   fisrt=data[0].lottery_full_name;//获取第一个的彩种名称
                  var good_name=data[i].lottery_name;//获取所有的html
                      good=good_name.substring(5);
                      good=good+"_find.html"; 
                     good_html.push(good);//获取所有的html的数组
                     // console.log(good);
                     html+='<li><a href="#">'+data[i].lottery_full_name+'</a></li>';
                    mian_msg+='<iframe src="./'+good+'" class="mainBody" style="display:none;height:2000px;width:100%;" frameborder=0 scrolling=no></iframe>'
                  return good_html,fisrt;       
                 })
                 
                  $('#caizhongjiekou').html(html);//将彩票彩种添加到$('#caizhongjiekou')上
                  $(".caipiao_leixing").text(fisrt);//默认的彩种列表
                  $(".main_Body").html(mian_msg);//添加所有选择的彩票数据
                  $(".mainBody").eq(0).show();


                  $("#caizhong_shu ul li ").each(function (i) {
                         $(this).click(function () {
                                var index=i;
                                // console.log(index)
                                $(".caipiao_leixing").text("");//将默认的数据去除
                                $(".mainBody").eq(i).show().siblings().hide();
                                $(this).css({//给当前的点击的元素添加样式
                                  "border-color":"red",
                                   "background":"url(./img/massage/checked3x.png) no-repeat right bottom",
                                 "background-size":"20% 50%"
                            }).siblings().css({"border-color":"gray","background":"none"});
                                $(".caipiao_leixing").text(($(this).text()));
                                $("#caizhong_shu").hide();
                                $(".sanjiao").show();
                                $(".daosanjiao").hide();     
              });
          }) 
               
       }
    })
})