// 江苏快三追号计划
$(function(){
    var plan="A";//计划 
   var count="2";//期数
   var code="20";//种类 00 定位胆 10冠军  冠亚 车位  冠亚和值  龙虎胆  守号
   var arr=["A","B"];

   $("#yiqiding1").click(function(){//二期和值
          count="2";
          plan="A";
          code="20";
          plans();
         
           $("#planB").click(function(){
            code="29";
            plans();
           })
            $("#planA").click(function(){
            code="20";
            plans();
           })
   })
 $("#yiqiding2").click(function(){//三期和值
          count="3";
          plan="A";
          code="20";
          plans();
         
           $("#planB").click(function(){
            code="29";
            plans();
           })
            $("#planA").click(function(){
            code="20";
            plans();
           })
   })
  $("#yiqiding3").click(function(){//三期独胆
          count="3";
          plan="A";
          code="21";
          plans();
   })
  $("#yiqiding4").click(function(){//三期二不同
          count="3";
          plan="A";
          code="22";
          plans();
   })
  $("#yiqiding5").click(function(){//五期守号
          count="5";
          plan="A";
          code="21";
          plans();
           $("#planB").click(function(){
            code="22";
            plans();
           })
            $("#planA").click(function(){
            code="21";
            plans();
           })
   })
  $("#yiqiding6").click(function(){//十期守号
          count="10";
          plan="A";
          code="23";
          plans();
           $("#planB").click(function(){
            code="22";
            plans();
           })
            $("#planA").click(function(){
            code="23";
            plans();
           })
   })
    $(".tabClick li").each(function(i){
          $(this).click(function(){
              plan=arr[i];
              plans()
          //     if ($(this)==$("#planB") && code=="29") {
          //       plan="B";
          //       code="29";
          //     plans()
          // }
          })
         
    }) 
                plans()
       function plans(){
         $.ajax({
             type: "post",
                      url: "http://47.94.140.92:8080/JDLot/lot/plan/list",
                      data: {"child_name":plan,"period_count":count,"lot_type":"2","plan_code":code,"lottery_name":"jsks"},//计划
                      //child_name计划ABC   period_count计划期数    lot_type 大彩种   plan_code  定位胆
                      contentType: "application/json",
                      dataType: "json",
                      async:true,
             success: function(data){
                   data=data.datas;
                   data=data.slice(0,100);
                    console.log(data)
                         $('#dingwei_jihua').empty();   //清空resText里面的所有内容
                         var html = '<li>'+
                      '<table>'+
                      '<tr>'+
                      '<th class="th_data1">期号</th>'+
                      '<th class="th_data1">序号</th>'+
                      '<th class="th_data2">定位计划</th>'+
                      '<th class="th_data3 lasts">回顾</th>'+
                      '</tr>'; 
                       var data_r="";
                       var data_w="";
                         $.each(data, function(i){
                           
                                   html+= '<tr>'+
                                             '<td class="th_data1">'+data[i].period_start+'-'+data[i].period_end+'</td>'+
                                             '<td class="th_data1">'+data[i].index_number+'</td>'+
                                             '<td class="th_data2">'+data[i].code_num+'</td>'+
                                             '<td class="th_data3 lasts lasts_success" id="lasts_success">'+(data[i].result==("000"||"00000"||"0000000000")?"✘":"✔")+'</td>'+    //回顾信息判断，如果匹配三期中的数据就返回“对”，否则“error”
                                             '</tr>'
                                           if (data[i].result == 1) {
                                                   data_r++;
                                                 
                                              } 
                                              var aas=data.slice(0,20);
                                               for (var j = 0; j < aas.length; j++) {
                                                if (data[j].result == 1) {
                                                    data_w++;
                                                } 
                                              }
                                  });
                                     html=html+'</table></li>';
         
                                $('#dingwei_jihua').html(html);//将数据放在ul中
                                
                                $(".ccs1").text(2*data_r+"%");
                                $(".ccs2").text(data_w/10+"%");

                       
                    }
         })
       }


});