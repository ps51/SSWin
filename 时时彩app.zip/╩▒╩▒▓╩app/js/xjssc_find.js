$(function(){
   var plan="A";//计划
   var count="1";//期数
   var code="00";//种类 00 定位胆 01大小 02单双

   plans();
   $("#yiqiding").click(function(){//一期定位胆
          count="1";
          plan="A";
          code="00";
          plans()
   })
    $("#yiqiding1").click(function(){//二期定位胆
          count="2";
          plan="A";
          code="00";
          plans()
   })
     $("#yiqiding2").click(function(){//三期定位胆
          count="3";
          plan="A";
          code="00";
          plans()
   })
       $("#yiqiding3").click(function(){//二期大小
          count="2";
          plan="A";
          code="01";
          plans()
   })
       $("#yiqiding4").click(function(){//三期大小
          count="3";
          plan="A";
          code="01";
          plans()
   })
       $("#yiqiding5").click(function(){//二期单双
          count="2";
          plan="A";
          code="02";
          plans()
   })
       $("#yiqiding6").click(function(){//三期单双
          count="3";
          plan="A";
          code="02";
          plans()
   })
       $("#yiqiding7").click(function(){//三期五星
          count="3";
          plan="A";
          code="03";
          plans()
   })
       $("#yiqiding8").click(function(){//二期直选
          count="2";
          plan="A";
          code="04";
          plans();
           // $("#planC").click(function(){
           //  alert("此计划不存在")
           // })
   })
      $("#yiqiding9").click(function(){//三期直选
          count="3";
          plan="A";
          code="04";
          plans();
           // $("#planC").click(function(){
           //  alert("此计划不存在")
           // })
   })
      $("#yiqiding10").click(function(){//三期组六
          count="3";
          plan="A";
          code="05";
          plans();
           // $("#planC").click(function(){
           //  alert("此计划不存在")
           // })
   })
    $("#yiqiding12").click(function(){//五期守号
          count="5";
          plan="A";
          code="03";
           plans();
           $("#planA").click(function(){
            code="03";
            plans();
           })
           $("#planB").click(function(){
            code="03";
            plans();
           })
           $("#planC").click(function(){
            code="05";
            plans();
           })
   })
    $("#yiqiding13").click(function(){//十期守号
          count="10";
          plan="A";
          code="07";
           plans()
             $("#planA").click(function(){
            code="07";
            plans();
           })
           $("#planB").click(function(){
            code="06";
            plans();
           })
           //  $("#planC").click(function(){
           //  alert("此计划不存在")
           // })
   })

var arr=["A","B","C"];
    $(".tabClick li").each(function(i){
          $(this).click(function(){
              plan=arr[i];
              plans();

          //五期守号特别处理
             if ($(this)==$("#planC") && code=="03") {
              code="05";
              plans()
          }
           if ($(this)==$("#planC") && code=="05") {
                 code="03";
                 plans()
          }
          })
    })

       function plans(){
        $.ajax({
                      type: "post",
                      url: "http://47.94.140.92:8080/JDLot/lot/plan/list",
                      data: {"child_name":plan,"period_count":count,"lot_type":"0","plan_code":code,"lottery_name":"xjssc"},//计划
                      //child_name计划ABC   period_count计划期数    lot_type 大彩种   plan_code  定位胆
                      contentType: "application/json",
                      dataType: "json",
                      async:true,
                      success: function(data){
                            data=data.datas;
                            data=data.slice(0,100);//截取前100条数据    
                        console.log(data);
                                  $('#dingwei_jihua').empty();   //清空 $('#dingwei_jihua')里面的所有内容
                                  var html = '<li>'+
                                             '<table>'+
                                             '<tr>'+
                                             '<th class="th_data1">期号</th>'+
                                             '<th class="th_data1">序号</th>'+
                                             '<th class="th_data2">计划</th>'+
                                             '<th class="th_data3 lasts">回顾</th>'+
                                             '</tr>'; 
                                             var data_r="";
                                             var data_w="";
                                  $.each(data, function(i){
                                    var results=data[i].result;
                                      // console.log(results);
                                      var successful="";
                                      if (results=="" && i==0) {
                                        successful="开奖中";
                                      } else if(results==1){
                                        successful="✔";
                                      }else{
                                        successful="✘";
                                      }
                                            html+= '<tr>'+
                                             '<td class="th_data1">'+data[i].period_start+'-'+data[i].period_end+'</td>'+
                                             '<td class="th_data1">'+data[i].index_number+'</td>'+
                                             '<td class="th_data2">'+data[i].code_num+'</td>'+
                                             '<td class="th_data3 lasts lasts_success" id="lasts_success">'+successful+'</td>'+    //回顾信息判断，如果匹配三期中的数据就返回“对”，否则“error”
                                             '</tr>'
                                          
                                                if (data[i].result == 1) {
                                                   data_r++;
                                                 
                                              } 
                                              var aas=data.slice(0,20);
                                               for (var j = 0; j < aas.length; j++) {
                                                if (data[j].result == 1) {
                                                    data_w++;
                                                } 
                                              }
                                  });

                                     html=html+'</table></li>';
         
                                $('#dingwei_jihua').html(html);//将数据放在ul中
                                
                                $(".ccs1").text(2*data_r+"%");
                                $(".ccs2").text(data_w/10+"%");
                              
                             
         }
     })
       }       

})
     