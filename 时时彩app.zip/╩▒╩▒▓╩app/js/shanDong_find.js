// 山东115追号计划
$(function(){
    var plan="A";//计划 
   var count="1";//期数
   var code="30";//种类 00 定位胆 10冠军  冠亚 车位  冠亚和值  龙虎胆  守号
   var arr=["A","B","C"];

   $("#yiqiding1").click(function(){//一期定位
          code="30";
      plan="A";
          plans()
   })
   $("#yiqiding2").click(function(){//二期定位
          count="2";
          plan="A";
          plans()
   })
 $("#yiqiding3").click(function(){//三期定位
          count="3";
          plan="A";
          plans()
   })
  $("#yiqiding4").click(function(){//二期直选复式
          count="2";
          plan="A";
          code="31";
          plans()
   })
   $("#yiqiding5").click(function(){//三期直选复式
          count="3";
          plan="A";
          code="31";
          plans()
   })
    $("#yiqiding6").click(function(){//五期守号
          count="5";
          plan="A";
          code="32";
          plans();
          $("#planB").click(function(){
            code="33";
            plans();
           })
            $("#planA").click(function(){
            code="32";
            plans();
           })
   })
      $("#yiqiding7").click(function(){//十期守号
          count="10";
          plan="A";
          code="34";
          plans()
   })
    $(".tabClick li").each(function(i){
          $(this).click(function(){
              plan=arr[i];
              plans()
              if ($(this)==$("#planB") && code=="32") {
              code="32";
              plans()
          }
          })
         
    }) 
                plans()
       function plans(){
         $.ajax({
             type: "post",
                      url: "http://47.94.140.92:8080/JDLot/lot/plan/list",
                      data: {"child_name":plan,"period_count":count,"lot_type":"3","plan_code":code,"lottery_name":"gd115"},//计划
                      //child_name计划ABC   period_count计划期数    lot_type 大彩种   plan_code  定位胆   lottery_name
                      contentType: "application/json",
                      dataType: "json",
                      async:true,
             success: function(data){
             	     data=data.datas;
             	     data=data.slice(0,100);
             	// console.log(data)
                         $('#dingwei_jihua').empty();   //清空resText里面的所有内容
                         var html = '<li>'+
										  '<table>'+
										  '<tr>'+
										  '<th class="th_data1">期号</th>'+
										  '<th class="th_data1">序号</th>'+
										  '<th class="th_data2">定位计划</th>'+
										  '<th class="th_data3 lasts">回顾</th>'+
										  '</tr>'; 
                       var data_r="";
                       var data_w="";
                         $.each(data, function(i){
                                   html+= '<tr>'+
									                           '<td class="th_data1">'+data[i].period_start+'-'+data[i].period_end+'</td>'+
                                             '<td class="th_data1">'+data[i].index_number+'</td>'+
                                             '<td class="th_data2">'+data[i].code_num+'</td>'+
                                             '<td class="th_data3 lasts lasts_success" id="lasts_success">'+( data[i].result==1 ? "✔":"✘")+'</td>'+ 
                                             '</tr>'//广东十一选五开奖结果待处理
                                           if (data[i].result == 1) {
                                                   data_r++;
                                                 
                                              } 
                                              var aas=data.slice(0,20);
                                               for (var j = 0; j < aas.length; j++) {
                                                if (data[j].result == 1) {
                                                    data_w++;
                                                } 
                                              }
                                  });
                                     html=html+'</table></li>';
         
                                $('#dingwei_jihua').html(html);//将数据放在ul中
                                
                                $(".ccs1").text(2*data_r+"%");
                                $(".ccs2").text(data_w/10+"%");

                       
                    }
         })
       }


});
